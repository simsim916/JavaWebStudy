export default function Footer() {
    return (
        <footer>
            <h2>🍅footer🍅</h2>
        </footer>
    );
}